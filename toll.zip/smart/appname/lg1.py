from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:root@localhost/smart-transport'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app)
@app.route('/')
def hom():
   return render_template('home.html')
@app.route('/adm2')
def adm2():
   return render_template('adm2.html',first=first.query.all())
@app.route('/adm3')
def adm3():
   return render_template('adm3.html',third=third.query.all())
@app.route('/adm6')
def adm6():
   return render_template('adm6.html',six=six.query.all())   
@app.route('/mail')
def mail():
   return render_template('mail.html')
@app.route('/lane1')
def lane1():
   return render_template('lane1.html')
@app.route('/lane2')
def lane2():
   return render_template('lane2.html')
@app.route('/lane3')
def lane3():
   return render_template('lane3.html')
@app.route('/tollreg')
def tollreg():
   return render_template('tollreg.html')
@app.route('/tollreg2')
def tollreg2():
   return render_template('tollreg2.html',re=re.query.all())
@app.route('/toll')
def toll():
   return render_template('toll.html')
@app.route('/contactus')
def contact():
   return render_template('contact us.html')
@app.route('/register')
def register():
   return render_template('register.html')
@app.route('/empt')
def empt():
   return render_template('empt.html')
@app.route('/empdetail')
def empdetail():
   return render_template('empdetail.html')
@app.route('/empview')
def empview():
   return render_template('empview.html',emp=emp.query.all())
@app.route('/Feedback')
def Feedback():
   return render_template('Feedback.html',five=five.query.all())
@app.route('/login')
def login():
   return render_template('login6.html')
@app.route('/signin')
def signin():
   return render_template('signin2.html')
@app.route('/profile/<name>')
def profile(name):
   return render_template('profile.html',first=first.query.filter_by(user_name='%s'%name))   
@app.route('/page2')
def pg():
   return render_template('page2.html')     
@app.route('/sender details')
def page():
   return render_template('sender details.html') 
@app.route('/receiver details')
def rec():   
	return render_template('receiver details.html')
@app.route('/admin')
def admin():   
	return render_template('admin22.html')
@app.route('/booking')
def booking():   
	return render_template('booking.html')
@app.route('/doc2')
def doc2():   
	return render_template('doc2.html')
@app.route('/doc4')
def doc4():   
	return render_template('doc4.html')
@app.route('/doc3')
def doc3():   
	return render_template('doc3.html')
@app.route('/ind')
def ind():   
	return render_template('indexnn.html')
@app.route('/tr')
def tr():   
	return render_template('truck.html')
@app.route('/cus')
def cus():   
	return render_template('truck2.html')
@app.route('/tol')
def tol():   
	return render_template('truck6.html')
@app.route('/sucess')
def sucess():   
	return render_template('sucess.html')	
@app.route('/view2')
def view2():   
	return render_template('view2.html')
@app.route('/view')
def view():   
	return render_template('view.html',second=second.query.all())
@app.route('/adm44')
def adm44():   
	return render_template('admin44.html')
@app.route('/ele44')
def ele44():   
	return render_template('elements44.html')
@app.route('/generic44')
def generic44():   
	return render_template('generic44.html')
@app.route('/paid')
def paid():   
	return render_template('paid.html',reg=reg.query.all())
@app.route('/register2')
def register2():   
	return render_template('register2.html')
@app.route('/bills')
def bills():   
	return render_template('bills.html',reg=reg.query.all())
@app.route('/payment')
def payment():   
	return render_template('payment.html',third=third.query.all())
@app.route('/appp/<name>')
def appp(name):   
	return render_template('payment.html',third=third.query.filter_by(Name='%s'%name))
class first(db.Model):
	id = db.Column('trans_id', db.Integer, primary_key = True)
	user_name = db.Column(db.String(100))
	Email = db.Column(db.String(100))
	password = db.Column(db.String(200))
	def __init__(self, user_name, Email, password ):
		self.user_name = user_name
		self.Email = Email
		self.password = password
	@app.route('/signin', methods = ['GET','POST'])
	def new():
		if request.method == 'POST':
			if not request.form['user_name'] or not request.form['Email']or not request.form['password']:
				flash('Please enter all the fields', 'error')
			else:
				trans = first(request.form['user_name'], request.form['Email'], request.form['password'])
				db.session.add(trans)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('login'))
				return render_template('signin2.html')
@app.route('/login', methods=['POST','GET'])
def loginn():
	if request.method=='GET':
		return render_template('login6.html')
	user_name = request.form['user_name']
	password = request.form['password']
	trans=first.query.filter_by(user_name=user_name,password=password).first() 
	if request.form['password'] == 'admin' and request.form['user_name'] == 'admin':
		return render_template("admin44.html")
	if trans is None:
		return render_template("login6.html")
	else:
	    return redirect(url_for('tol',name=user_name))
class second(db.Model):
	id = db.Column('row_id', db.Integer, primary_key = True)
	user_type = db.Column(db.String(100))
	Name = db.Column(db.String(100))
	Email = db.Column(db.String(100))
	Location = db.Column(db.String(100))
	Destingnation = db.Column(db.String(100))
	Capacity_Of_Truck = db.Column(db.String(100))
	Contact = db.Column(db.String(100))
	
	def __init__(self,user_type, Name,Email,Location,Destingnation,Capacity_Of_Truck,Contact):
		
		self.user_type = user_type
		self.Name = Name
		self.Email = Email
		self.Location = Location
		self.Destingnation = Destingnation
		self.Capacity_Of_Truck= Capacity_Of_Truck
		self.Contact = Contact
		
	@app.route('/tru', methods = ['GET','POST'])
	def new1():
		if request.method == 'POST':
			if not request.form['user_type'] or not request.form['Name'] or not request.form['Email'] or not request.form['Location'] or not request.form['Destingnation'] or not request.form['Capacity_Of_Truck'] or not request.form['Contact']:
				flash('Please enter all the fields', 'error')
			else:
				row = second( request.form['user_type'], request.form['Name'], request.form['Email'], request.form['Location'], request.form['Destingnation'], request.form['Capacity_Of_Truck'], request.form['Contact'])
				db.session.add(row)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('sucess'))
				return render_template('tr.html')
class third(db.Model):
	id = db.Column('feed_id', db.Integer, primary_key = True)
	number = db.Column(db.String(100))
	location = db.Column(db.String(100))
	destination = db.Column(db.String(100))
	goods = db.Column(db.String(100))
	contact = db.Column(db.String(100))
	def __init__(self, number, location, destination, goods, contact):
		self.number = number
		self.location = location
		self.destination = destination
		self.goods = goods
		self.contact = contact
	@app.route('/register', methods = ['GET','POST'])
	def new3():
		if request.method == 'POST':
			if  not request.form['number'] or not request.form['location'] or not request.form['destination'] or not request.form['goods'] or not request.form['contact']:
	
				flash('Please enter all the fields', 'error')
			else:
				raw = third( request.form['number'], request.form['location'], request.form['destination'], request.form['goods'], request.form['contact'])

				db.session.add(raw)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('register2'))
				return render_template('register.html')

class fourth(db.Model):
	id = db.Column('com_id', db.Integer, primary_key = True)
	Company_Name = db.Column(db.String(100))
	Email = db.Column(db.String(100))
	Location = db.Column(db.String(100))
	Destingnation = db.Column(db.String(100))
	Type_Of_goods = db.Column(db.String(100))
	Contact = db.Column(db.String(100))
	def __init__(self, Company_Name, Address, City, State, Pincode,Truck_type,Passing_weight, Mobile_number, Office_number, Email_Address):
		self.Company_Name = Company_Name
		self.Email = Email
		self.Location = Location
		self.Destingnation = Destingnation
		self.Type_Of_goods= Type_Of_Goods
		self.Contact = Contact
	@app.route('/truck6', methods = ['GET','POST'])
	def new4():
		if request.method == 'POST':
			if  not request.form['Company_Name'] or not request.form['Email'] or not request.form['Location'] or not request.form['Destingnation'] or not request.form['Type_Of_goods'] or not request.form['Contact']:

				flash('Please enter all the fields', 'error')			
			else:
				com = fourth( request.form['Company_Name'], request.form['Email'], request.form['Location'], request.form['Destingnation'], request.form['Type_Of_goods'], request.form['Contact'])
				db.session.add(com)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('book'))
				return render_template('truck3.html')
class five(db.Model):
	id = db.Column('feed_id', db.Integer, primary_key = True)
	Name = db.Column(db.String(100))
	Email = db.Column(db.String(100))
	Feedback = db.Column(db.String(100))
	def __init__(self, Name, Email, Feedback):
		self.Name = Name
		self.Email = Email
		self.Feedback = Feedback
		
	@app.route('/doc3', methods = ['GET','POST'])
	def new5():
		if request.method == 'POST':
			if  not request.form['Name'] or not request.form['Email'] or not request.form['Feedback']:

				flash('Please enter all the fields', 'error')			
			else:
				feed = five( request.form['Name'], request.form['Email'], request.form['Feedback'])
				db.session.add(feed)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('doc3'))
				return render_template('doc3.html')

class six(db.Model):
	id = db.Column('rw_id', db.Integer, primary_key = True)
	number = db.Column(db.String(100))
	RC = db.Column(db.String(100))
	INC = db.Column(db.String(100))
	WEIGHT = db.Column(db.String(100))
	def __init__(self, number, RC, INC, WEIGHT):
		self.number = number
		self.RC = RC
		self.INC = INC
		self.WEIGHT = WEIGHT
	@app.route('/register2', methods = ['GET','POST'])
	def new6():
		if request.method == 'POST':
			if  not request.form['number'] or not request.form['RC'] or not request.form['INC'] or not request.form['WEIGHT']:
	
				flash('Please enter all the fields', 'error')
			else:
				rw = six( request.form['number'], request.form['RC'], request.form['INC'], request.form['WEIGHT'])
				db.session.add(rw)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('payment'))
				return render_template('register2.html')
class re(db.Model):
	id = db.Column('tol_id', db.Integer, primary_key = True)
	vehicle = db.Column(db.String(100))
	single = db.Column(db.String(100))
	retur = db.Column(db.String(100))
	daily = db.Column(db.String(100))
	trip = db.Column(db.String(100))
	monthly = db.Column(db.String(100))
	def __init__(self, vehicle, single, retur, daily, trip, monthly):
		self.vehicle = vehicle
		self.single = single
		self.retur = retur
		self.daily = daily
		self.trip = trip
		self.monthly = monthly
	@app.route('/tollreg', methods = ['GET','POST'])
	def new7():
		if request.method == 'POST':
			if  not request.form['vehicle'] or not request.form['single'] or not request.form['retur'] or not request.form['daily'] or not request.form['trip'] or not request.form['monthly']:
				flash('Please enter all the fields', 'error')
			else:
				tol = re( request.form['vehicle'], request.form['single'], request.form['retur'], request.form['daily'], request.form['trip'], request.form['monthly'])
				db.session.add(tol)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('payment'))
				return render_template('tollreg.html')
class reg(db.Model):
	id = db.Column('tolr_id', db.Integer, primary_key = True)
	number = db.Column(db.String(100))
	vehicle = db.Column(db.String(100))
	trip = db.Column(db.String(100))
	amount = db.Column(db.String(100))
	contact = db.Column(db.String(100))
	def __init__(self, number, vehicle, trip, amount, contact):
		self.number = number
		self.vehicle = vehicle
		self.trip = trip
		self.amount = amount
		self.contact = contact
	@app.route('/tr', methods = ['GET','POST'])
	def new8():
		if request.method == 'POST':
			if   not request.form['number'] or not request.form['vehicle'] or not request.form['trip'] or not request.form['amount'] or not request.form['contact']:
				flash('Please enter all the fields', 'error')
			else:
				tolr = reg( request.form['number'], request.form['vehicle'], request.form['trip'], request.form['amount'], request.form['contact'])
				db.session.add(tolr)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('paid'))
				return render_template('truck.html')
class emp(db.Model):
	id = db.Column('empl_id', db.Integer, primary_key = True)
	name = db.Column(db.String(100))
	qual = db.Column(db.String(100))
	dob = db.Column(db.String(100))
	gender = db.Column(db.String(100))
	contact = db.Column(db.String(100))
	email = db.Column(db.String(100))
	def __init__(self, name, qual, dob, gender, contact, email):
		self.name = name
		self.qual = qual
		self.dob = dob
		self.gender = gender
		self.contact = contact
		self.email = email
	@app.route('/empdetail', methods = ['GET','POST'])
	def new9():
		if request.method == 'POST':
			if  not request.form['name'] or not request.form['qual'] or not request.form['dob'] or not request.form['gender'] or not request.form['contact'] or not request.form['email']:
				flash('Please enter all the fields', 'error')
			else:
				empl = emp( request.form['name'], request.form['qual'], request.form['dob'], request.form['gender'], request.form['contact'], request.form['email'])
				db.session.add(empl)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('admin'))
				return render_template('empdetail.html')
@app.route('/status/<int:id>' , methods=['POST', 'GET'])
def status1(id):
	empl=emp.query.filter_by(id=id).delete()
	db.session.commit()
	return redirect(url_for('empview'))	

	
if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)
