from flask import Flask,render_template
app = Flask(__name__)
@app.route('/index')
def index():
   return render_template('index.html')
@app.route('/aboutus')
def about():
   return render_template('about.html')
@app.route('/contactus')
def contact():
   return render_template('contact us.html')
@app.route('/login2')
def log():
   return render_template('login2.html')
@app.route('/signin')
def sign():
   return render_template('signin.html')
@app.route('/signup')
def signup():
   return render_template('login2.html')
@app.route('/doc')
def doc():
   return render_template('doc.html')      
if __name__ == '__main__':
	app.run(debug = True)
